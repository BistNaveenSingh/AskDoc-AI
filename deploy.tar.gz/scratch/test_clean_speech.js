let text = `
### 1. Profile & Professional Summary
* **Candidate Name:** Bist Naveen Singh
* **Location:** Hyderabad, Telangana
* **Performance:** CGPA: 7.01/10
* **StudentSolution.io** *(React.js, Next.js, Node.js, Express.js, MongoDB)*
Reduced user tool discovery time by 40%. Implemented secure Google OAuth authentication.
IoT-Based Women Safety System (ESP32, Blynk, Wi-Fi Protocols)
Diploma -> B.Tech pathway.
| Category | Skills |
| --- | --- |
| Frontend | React, HTML |
`;

text = text.replace(/```[\s\S]*?```/g, 'Code block omitted.');
text = text.replace(/`([^`]+)`/g, '$1');
text = text.replace(/\|\s*[-:]+[-|\s:]*\|/g, ' ');
text = text.replace(/\|/g, ', ');
text = text.replace(/^#{1,6}\s*(.+)$/gm, '$1. ');
text = text.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');
text = text.replace(/https?:\/\/\S+/g, '');
text = text.replace(/(\*\*|__)(.*?)\1/g, '$2');
text = text.replace(/(\*|_)(.*?)\1/g, '$2');
text = text.replace(/~~(.*?)~~/g, '$1');
text = text.replace(/^\s*[-*+•]\s+/gm, '');
text = text.replace(/\(Page\s*\d+\)/gi, '');
text = text.replace(/(\d+)\/(\d+)/g, '$1 out of $2');
text = text.replace(/(→|->|-->)/g, ' to ');
text = text.replace(/\bOAuth\b/gi, 'O-Auth');
text = text.replace(/\bIoT\b/gi, 'I-o-T');
text = text.replace(/\bESP32\b/gi, 'E-S-P 32');
text = text.replace(/\bCGPA\b/gi, 'C-G-P-A');
text = text.replace(/\bReact\.js\b/gi, 'React');
text = text.replace(/\bNext\.js\b/gi, 'Next J S');
text = text.replace(/\bNode\.js\b/gi, 'Node J S');
text = text.replace(/\bExpress\.js\b/gi, 'Express');
text = text.replace(/\bStudentSolution\.io\b/gi, 'Student Solution dot I O');
text = text.replace(/[*_~`]/g, '');
text = text.replace(/,\s*,/g, ',');
text = text.replace(/\s*,\s*/g, ', ');
text = text.replace(/^,\s*/, '');
text = text.replace(/[ \t]+/g, ' ');
text = text.replace(/\n+/g, ' ').trim();

console.log('CLEAN SPOKEN TEXT:');
console.log(text);
