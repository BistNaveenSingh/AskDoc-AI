import os
import sys
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Add the project root to the python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.embeddings.vector_store import get_retriever

def test_hybrid_retrieval():
    print("Testing get_retriever()...")
    retriever = get_retriever(k=4)
    
    if not retriever:
        print("Retriever is None. Do you have documents in your vector store?")
        return
        
    print(f"Successfully loaded retriever of type: {type(retriever).__name__}")
    
    # Try a query
    query = "What is the CGPA or percentage?"
    print(f"\nQuerying: '{query}'")
    
    docs = retriever.invoke(query)
    
    print(f"\nFound {len(docs)} documents:")
    for i, doc in enumerate(docs):
        print(f"--- Doc {i+1} [{doc.metadata.get('source', 'Unknown')}] ---")
        # Print first 100 characters of content
        content = doc.page_content.replace('\n', ' ')
        print(content[:100] + "...")

if __name__ == "__main__":
    test_hybrid_retrieval()
