import streamlit as st
import streamlit.components.v1 as components
import json

st.title("Native Mention Test")

docs = ["employee_handbook.pdf", "financial_report.pdf", "benefits_guide.pdf"]
docs_json = json.dumps(docs)

st.chat_message("assistant").write("Hello! Try mentioning a doc below.")

user_input = st.chat_input("Type something and use @...")
if user_input:
    st.write(f"You sent: {user_input}")

# Inject JS
js_code = f"""
<script>
    const docs = {docs_json};
    const parentDoc = window.parent.document;
    
    function setupMention() {{
        const textarea = parentDoc.querySelector('textarea[data-testid="stChatInputTextArea"]');
        if (!textarea) {{
            setTimeout(setupMention, 500);
            return;
        }}
        
        if (textarea.dataset.mentionAttached) return;
        textarea.dataset.mentionAttached = 'true';
        
        let popup = parentDoc.getElementById('native-mention-popup');
        if (!popup) {{
            popup = parentDoc.createElement('div');
            popup.id = 'native-mention-popup';
            popup.style.display = 'none';
            popup.style.position = 'absolute';
            popup.style.bottom = '100%';
            popup.style.left = '0';
            popup.style.width = '100%';
            popup.style.maxHeight = '200px';
            popup.style.overflowY = 'auto';
            popup.style.backgroundColor = '#2f2f2f';
            popup.style.border = '1px solid rgba(255,255,255,0.1)';
            popup.style.borderRadius = '16px';
            popup.style.zIndex = '999999';
            popup.style.marginBottom = '10px';
            popup.style.boxShadow = '0 10px 20px rgba(0,0,0,0.3)';
            popup.style.padding = '8px 0';
            
            const container = parentDoc.querySelector('[data-testid="stChatInput"]');
            if (container) {{
                container.style.position = 'relative';
                container.appendChild(popup);
            }}
        }}
        
        textarea.addEventListener('input', function(e) {{
            const val = textarea.value;
            const cursor = textarea.selectionStart;
            const textBefore = val.substring(0, cursor);
            const lastAt = textBefore.lastIndexOf('@');
            
            if (lastAt !== -1 && (lastAt === 0 || textBefore[lastAt - 1] === ' ')) {{
                const query = textBefore.substring(lastAt + 1);
                const filtered = docs.filter(d => d.toLowerCase().includes(query.toLowerCase()));
                
                if (filtered.length > 0) {{
                    popup.innerHTML = '';
                    filtered.forEach(doc => {{
                        const item = parentDoc.createElement('div');
                        item.textContent = doc;
                        item.style.padding = '10px 16px';
                        item.style.color = '#ececec';
                        item.style.cursor = 'pointer';
                        
                        item.addEventListener('mouseenter', () => item.style.backgroundColor = '#404040');
                        item.addEventListener('mouseleave', () => item.style.backgroundColor = 'transparent');
                        
                        item.addEventListener('mousedown', function(evt) {{
                            evt.preventDefault();
                            const before = val.substring(0, lastAt);
                            const after = val.substring(cursor);
                            
                            const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
                            nativeInputValueSetter.call(textarea, before + '@' + doc + ' ' + after);
                            
                            textarea.dispatchEvent(new Event('input', {{ bubbles: true }}));
                            
                            popup.style.display = 'none';
                            textarea.focus();
                        }});
                        
                        popup.appendChild(item);
                    }});
                    popup.style.display = 'block';
                }} else {{
                    popup.style.display = 'none';
                }}
            }} else {{
                popup.style.display = 'none';
            }}
        }});
        
        textarea.addEventListener('blur', () => {{
            setTimeout(() => popup.style.display = 'none', 150);
        }});
    }}
    
    setupMention();
</script>
"""
components.html(js_code, height=0, width=0)
