import requests
import time

def run():
    print("Waiting for FastAPI...")
    for _ in range(15):
        try:
            r = requests.get("http://127.0.0.1:8000/documents", timeout=2)
            if r.status_code == 200:
                print("FastAPI is ready. Active docs:", r.json())
                break
        except Exception:
            time.sleep(1)
            
    # Test 1: 'hey' greeting
    r1 = requests.post("http://127.0.0.1:8000/ask", json={"question": "hey"}, timeout=20)
    print("\n--- Test 1: Greeting 'hey' ---")
    print("Status:", r1.status_code)
    data1 = r1.json()
    print("Answer:", data1.get("answer"))
    print("Sources:", data1.get("sources"))
    assert data1.get("sources") == [], f"FAILED: Expected empty sources for greeting, got {data1.get('sources')}"

    # Test 2: 'hello there' greeting
    r2 = requests.post("http://127.0.0.1:8000/ask", json={"question": "hello there"}, timeout=20)
    print("\n--- Test 2: Greeting 'hello there' ---")
    data2 = r2.json()
    print("Answer:", data2.get("answer"))
    print("Sources:", data2.get("sources"))
    assert data2.get("sources") == [], f"FAILED: Expected empty sources for greeting, got {data2.get('sources')}"

    # Test 3: Off-topic / unanswerable question
    r3 = requests.post("http://127.0.0.1:8000/ask", json={"question": "What is the capital of France?"}, timeout=20)
    print("\n--- Test 3: Off-topic question ---")
    data3 = r3.json()
    print("Answer:", data3.get("answer"))
    print("Sources:", data3.get("sources"))
    assert data3.get("sources") == [], f"FAILED: Expected empty sources for 'I don't know', got {data3.get('sources')}"

    # Test 4: Document-grounded question
    r4 = requests.post("http://127.0.0.1:8000/ask", json={"question": "What projects did the candidate work on?"}, timeout=30)
    print("\n--- Test 4: Document question ---")
    data4 = r4.json()
    print("Answer preview:", data4.get("answer")[:150] + "...")
    print("Sources:", data4.get("sources"))
    sources = data4.get("sources", [])
    assert any(s.get("source") == "resume001.pdf" for s in sources), "FAILED: Expected resume001.pdf citation"
    assert not any("cars" in s.get("source", "").lower() for s in sources), "FAILED: cars_data.csv must never appear!"

    print("\n>>> ALL CITATION & GUARDRAIL TESTS PASSED SUCCESSFULLY! <<<")

if __name__ == "__main__":
    run()
