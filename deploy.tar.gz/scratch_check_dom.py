import urllib.request
import re

req = urllib.request.Request('http://localhost:8501', headers={'User-Agent': 'Mozilla/5.0'})
try:
    with urllib.request.urlopen(req) as resp:
        html = resp.read().decode('utf-8')
        testids = re.findall(r'data-testid=[\'"]([^\'"]+)[\'"]', html)
        print("Test IDs found:", sorted(list(set(testids))))
except Exception as e:
    print("Error:", e)
