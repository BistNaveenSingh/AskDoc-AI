# FastAPI REST API module
